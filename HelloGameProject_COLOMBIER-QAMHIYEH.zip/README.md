# Quick instructions

/!\ You need python3, pika, and PyQt5 to run this project /!\

## Server

To run the server, go to the server directory and launch `main.py`. You need to specify the topology, and can also specify which particular nodes you want to start, or the rabbitMQ server

## Client

The client doesn't take any parameter. Just navigate to the client directory and run `main.py`. Furthermore, you can click connect straight away without typing any value, which will start a game using a random name and the localhost server.
